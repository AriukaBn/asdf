/* let i = prompt("i too");
let n = prompt("n too");

function bla () {
    if (i < n) {
        console.log(n);
    } else if (i > n) {
        console.log(i);
    } else if (i = n) {
        console.log("2 too adilhan ", i, "bn");
    }
}
bla(); */


/* let i = prompt("ondor");
let n = prompt("orgon");

if (i > n){
    console.log("bosoo");
} else if (i < n){
    console.log("hevtee");
} else if (i + n){
    console.log("tegsh ontsogt");
}; */


/* let i = prompt("too");
let n = i;

for (i = 0; i <= n; i += 2) {
    console.log(i);
} */
